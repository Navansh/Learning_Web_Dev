g_isExtrasCKPluginRunning = 0
