return {
	
	LrSdkVersion = 3.0,
	LrSdkMinimumVersion = 3.0, -- minimum SDK version required by this plug-in

	LrToolkitIdentifier = 'com.macphunCK.extrasPlugin',

	LrPluginName = LOC("$$$/MPExtrasPluginAppNameExtras/PluginName=Macphun Creative Kit"),
	
	-- Add the menu item to the File menu.
	
	LrExportMenuItems = menuItems,
	LrLibraryMenuItems = menuItems,
	LrInitPlugin = "ExtrasCKInit.lua",
	LrShutdownPlugin = "ExtrasCKShutdown.lua",

	VERSION = { display = "1.0.1", },
}


	