menuItems = {
	{
		title = LOC("$$$/MPExtrasPluginAppName/ExportMenuTitle=Transfer to MPExtrasAppName"),
		file = "ExportMenuItem.lua",
		enabledWhen = "photosAvailable"
	},
}

return {
	
	LrSdkVersion = 3.0,
	LrSdkMinimumVersion = 3.0, -- minimum SDK version required by this plug-in

	LrToolkitIdentifier = 'com.macphun.exportMPExtrasPluginAppNamePlugin',

	LrPluginName = LOC("$$$/MPExtrasPluginAppNameExtras/PluginName=MPExtrasAppName"),
	
	-- Add the menu item to the File menu.
	
	LrExportMenuItems = menuItems,
	LrLibraryMenuItems = menuItems,
	LrInitPlugin = "ExportInit.lua",
	LrShutdownPlugin = "ExportShutdown.lua",
	LrExportServiceProvider = {
		title = LOC("$$$/MPExtrasPluginAppNameExtras/PluginName=MPExtrasAppName"),
		file = 'ExportServiceProvider.lua',
--		builtInPresetsDir = "presets",
	},

	VERSION = { display = "1.0.1", },
}


	