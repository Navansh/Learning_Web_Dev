return {
	
	LrSdkVersion = 3.0,
	LrSdkMinimumVersion = 3.0, -- minimum SDK version required by this plug-in

	LrToolkitIdentifier = 'com.macphun.exportMPExtrasPluginAppNamePlugin',

	LrPluginName = LOC("$$$/MPExtrasPluginAppNameExtras/PluginName=MPExtrasAppName"),
	
	-- Add the menu item to the File menu.
	
	LrInitPlugin = "ExportInitCK.lua",
--	LrShutdownPlugin = "ExportShutdown.lua",
	LrExportServiceProvider = {
		title = LOC("$$$/MPExtrasPluginAppNameExtras/PluginName=MPExtrasAppName"),
		file = 'ExportServiceProvider.lua',
--		builtInPresetsDir = "presets",
	},

	VERSION = { display = "1.0.1", },
}


	