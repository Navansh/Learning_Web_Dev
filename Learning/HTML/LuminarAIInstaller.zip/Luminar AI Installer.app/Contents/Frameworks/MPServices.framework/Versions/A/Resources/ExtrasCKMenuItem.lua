	{
		title = LOC("$$$/MPExtrasPluginAppName/ExportMenuTitle=Transfer to MPExtrasAppName"),
		file = "ExtrasMPExtrasPluginAppNameMenuItem.lua",
		enabledWhen = "photosAvailable"
	},
