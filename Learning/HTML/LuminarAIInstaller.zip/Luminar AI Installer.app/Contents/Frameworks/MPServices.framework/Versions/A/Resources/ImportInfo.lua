return
{
	LrSdkVersion = 3.0,
	LrSdkMinimumVersion = 3.0,

	LrPluginName = "MPExtrasAppName Importer",
	LrToolkitIdentifier = "com.macphun.importMPExtrasPluginAppNamePlugin",
	
	LrInitPlugin = "ImportPluginInit.lua",
	LrShutdownPlugin = "ImportPluginShutdown.lua",
	LrExportServiceProvider =
	{
		title = "MPExtrasAppName Importer",
		file = "ImportPluginService.lua",
	},

	VERSION = { display="1.0.1", },
}
