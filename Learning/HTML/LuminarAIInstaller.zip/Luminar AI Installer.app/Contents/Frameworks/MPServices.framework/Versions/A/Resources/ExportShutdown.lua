g_MPExtrasPluginAppName_isPluginRunning = 0
